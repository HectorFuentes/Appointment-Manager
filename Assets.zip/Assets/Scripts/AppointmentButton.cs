﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using static Database;
using System;

public class AppointmentButton : MonoBehaviour
{
    public List<TMP_Text> textFields;
    public Appointment_Set appointment;
    public string message = "";
    public AppointmentLister al;

    public GameObject button;

    public void SetUp()
    {
        if(message == "")
        {
            textFields[0].text = appointment.date;
            textFields[1].text = appointment.firstName;
            textFields[2].text = appointment.lastName;
            textFields[3].text = appointment.startTime + " - " + appointment.endTime;
            //textFields[4].text = ;
            textFields[5].text = appointment.email;
            textFields[6].text = appointment.phone;
            textFields[7].text = appointment.subject;
            textFields[8].text = appointment.notes;
        }
        else
        {
            textFields[0].text =
            textFields[1].text =
            textFields[2].text =
            textFields[3].text =
            textFields[4].text =
            textFields[5].text =
            textFields[6].text =
            textFields[7].text =
            textFields[8].text = "";
            textFields[9].text = message;
            button.SetActive(false);
            GetComponent<RectTransform>().sizeDelta = new Vector2(600, 100);
        }
    }

    public void Delete()
    {
        string start = appointment.date + " " + appointment.startTime;

        DateTime date1 = DateTime.Now;
        DateTime date2;
        try
        {
            date2 = DateTime.Parse(start);
            TimeSpan timeSpan = date2.Subtract(date1);
            //Debug.Log(timeSpan);

            if (timeSpan.TotalHours <= 48)
            {
                FindObjectOfType<Buttons>().Error("Can only delete an appointment up to 48 hours before the appointment date.");
            }
            else
            {
                FindObjectOfType<Buttons>().Delete(appointment.ID);
                al.Refresh();
            }
        }
        catch (FormatException)
        {
            FindObjectOfType<Buttons>().Error("48 Hour Parse Error");
        }
    }
}
