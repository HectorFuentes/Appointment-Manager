﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NavigationObject : MonoBehaviour
{
    public bool isOverlay;
    public NavigationObject overlayed;

    public NavigationObject LeftScreen;
    public NavigationObject RightScreen;
    public NavigationObject UpScreen;
    public NavigationObject DownScreen;

    public bool isBackExempt;
    public NavigationObject lastPage;
}
