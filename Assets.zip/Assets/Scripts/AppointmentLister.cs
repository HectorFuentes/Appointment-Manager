﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Database;
using System;

public class AppointmentLister : MonoBehaviour
{
    List<GameObject> gameObjects = new List<GameObject>();
    public GameObject button;
    public List<Appointment_Set> appointments1;
    string lastDate = "";

    public void Refresh()
    {
        List<Appointment_Set> appointments2 = new List<Appointment_Set>();
        appointments2.AddRange(appointments1);
        
        // clear
        foreach (GameObject item in gameObjects) Destroy(item);
        gameObjects.Clear();


        for(int i = 0; i < appointments1.Count;i++)
        {
            Appointment_Set min = appointments2[0];
            
            foreach (Appointment_Set item2 in appointments2)
            {
                DateTime date1;
                DateTime date2;
                try
                {
                    date1 = DateTime.Parse(item2.date);
                    date2 = DateTime.Parse(min.date);

                    if (date1.CompareTo(date2) < 0)
                    {
                        min = item2;

                    }
                }
                catch (FormatException)
                {
                    FindObjectOfType<Buttons>().Error("Appointment Lister Parse Error");
                }
            }

            DateTime date3;
            DateTime date4;
            try
            {
                if(lastDate == "")
                {
                    //print date thing
                    GameObject temp1 = Instantiate(button, transform);
                    AppointmentButton ab1 = temp1.GetComponent<AppointmentButton>();
                    ab1.message = min.date;
                    ab1.SetUp();
                    gameObjects.Add(temp1);
                }
                else
                {
                    date3 = DateTime.Parse(lastDate);
                    date4 = DateTime.Parse(min.date);
                    if(date3.CompareTo(date4) != 0)
                    {
                        // print date thing
                        //Debug.Log(date3 + " " + date4);
                        GameObject temp1 = Instantiate(button, transform);
                        AppointmentButton ab1 = temp1.GetComponent<AppointmentButton>();
                        ab1.message = min.date;
                        ab1.SetUp();
                        gameObjects.Add(temp1);
                    }
                }

                lastDate = min.date;
            }
            catch (FormatException)
            {
                FindObjectOfType<Buttons>().Error("Appointment Lister Parse Error #2");
            }

            // print min button
            GameObject temp = Instantiate(button, transform);
            AppointmentButton ab = temp.GetComponent<AppointmentButton>();
            ab.appointment = min;
            appointments2.Remove(min);
            ab.al = this;
            ab.SetUp();
            gameObjects.Add(temp);
        }
    }
}
