﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Networking;
using System.Text;

public class Database : MonoBehaviour
{
    Buttons buttons;

    [Serializable]
    public class Appointment_Set
    {
        public int ID;

        public string date;
        public string firstName;
        public string lastName;
        public string startTime;
        public string endTime;
        public string email;
        public string phone;
        public string subject;
        public string notes;
    }

    [Serializable]
    public class Appointment_Get
    {
        public int ID;
        public string firstName;
        public string error;
    }

    [Serializable]
    public class Delete_Set
    {
        public int ID;
    }

    [Serializable]
    public class Delete_Get
    {
        public string error;
    }

    [Serializable]
    public class Login_Set
    {
        public string username;
        public string password;
    }

    [Serializable]
    public class Login_Get
    {
        public int ID;
        public string error;
    }

    [Serializable] // unessesary
    public class Load_Set
    {
        public string search = "";
        public int ID = 0;
    }

    [Serializable]
    public class Load_Get
    {
        public string[] results; // undeliminated list
        public string error;
    }

    void Start()
    {
        buttons = GetComponent<Buttons>();

        Load_Set set = new Load_Set();
        Load(set);
    }

    public void AddAppointment(Appointment_Set set)
    {
        StartCoroutine(Post(CreateApiPostRequest("/AddAppointment.php", set), AddAppointment));
    }

    void AddAppointment(string reply)
    {
        Appointment_Get get = JsonUtility.FromJson<Appointment_Get>(reply);

        if (get.error != "") buttons.Error(get.error);
        else buttons.Confirm(get.firstName, get.ID);
    }

    public void Load(Load_Set set)
    {
        StartCoroutine(Post(CreateApiPostRequest("/Load.php", set), Load));
    }

    void Load(string reply)
    {
        //Debug.Log(reply);
        Load_Get get = JsonUtility.FromJson<Load_Get>(reply);
        buttons.SetActiveLoad(get);
    }

    public void Login(Login_Set set)
    {
        StartCoroutine(Post(CreateApiPostRequest("/Login.php", set), Login));
    }

    void Login(string reply)
    {
        //Debug.Log(reply);
        Login_Get get = JsonUtility.FromJson<Login_Get>(reply);

        if (get.error != "") buttons.Error(get.error);
        else buttons.Login(get.ID);
    }

    public void EditAppointment(Appointment_Set set)
    {
        StartCoroutine(Post(CreateApiPostRequest("/EditAppointment.php", set), EditAppointment));
    }

    void EditAppointment(string reply)
    {
        // do nothing
    }

    public void Delete(Delete_Set set)
    {
        StartCoroutine(Post(CreateApiPostRequest("/DeleteAppointment.php", set), Delete));
    }

    void Delete(string reply)
    {
        // do nothing
    }

    IEnumerator Post(UnityWebRequest request, System.Action<string> callback)
    {
        using (request)
        {
            yield return request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
            {
                Debug.Log(request.error);
            }
            else
            {
                callback(request.downloadHandler.text);
            }
        }
    }

    UnityWebRequest CreateApiRequest(string url, string method, object body)
    {
        string bodyString = null;
        if (body is string)
        {
            bodyString = (string)body;
        }
        else if (body != null)
        {
            bodyString = JsonUtility.ToJson(body);
        }

        UnityWebRequest request = new UnityWebRequest();
        request.url = url;
        request.method = method;
        request.downloadHandler = new DownloadHandlerBuffer();
        request.uploadHandler = new UploadHandlerRaw(string.IsNullOrEmpty(bodyString) ? null : Encoding.UTF8.GetBytes(bodyString));
        request.SetRequestHeader("Accept", "application/json");
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("User-Agent", "DefaultBrowser");
        request.timeout = 60;
        return request;
    }

    public UnityWebRequest CreateApiPostRequest(string actionUrl, object body = null)
    {
        return CreateApiRequest("hectorfuentes.infinityfreeapp.com/LAMPAPI" + actionUrl, UnityWebRequest.kHttpVerbPOST, body);
    }
}
