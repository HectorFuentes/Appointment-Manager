﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Globalization;
using System.Text.RegularExpressions;
using static Database;
using TMPro;
using System.Text;

public class Buttons : MonoBehaviour
{
    
    Database db;
    public AppointmentLister al;
    

    // Start is called before the first frame update
    void Start()
    {
        db = GetComponent<Database>();
    }
    
    [Tooltip(
        "0 string date " +
        "1 string firstName " +
        "2 string lastName " +
        "3 string startTime " +
        "4 string endTime " +
        "5 string email " +
        "6 string phone " +
        "7 string subject " +
        "8 string notes;")]
    public List<TMP_InputField> addTextFields;
    public List<TMP_InputField> editTextFields;
    public List<TMP_InputField> loginTextFields;

    [SerializeField]
    GameObject confirmAddButton;
    [SerializeField]
    GameObject confirmAddButtonText;
    //public Button confirmEdit;
    //public Button confirmLogin;

    [SerializeField]
    GameObject errorDisplay;
    [SerializeField]
    TMP_Text errorText;

    [SerializeField]
    NavigationObject confirmDisplay;
    [SerializeField]
    TMP_Text confirmText;

    [SerializeField]
    NavigationObject appointmentPage;
    [SerializeField]
    NavigationObject editPage;
    [SerializeField]
    NavigationObject homePage;

    Appointment_Set appointment = new Appointment_Set();
    Login_Set login = new Login_Set();

    public bool dateInputed;
    public bool firstNameInputed;
    public bool lastNameInputed;
    public bool startTimeInputed;
    public bool endTimeInputed;
    public bool emailInputed;
    public bool phoneInputed;
    public bool subjectInputed;
    public bool notesInputed;

    void RefreshFields()
    {
        foreach (TMP_InputField field in addTextFields)
        {
            field.text = "";
        }

        foreach (TMP_InputField field in editTextFields)
        {
            field.text = "";
        }

        foreach (TMP_InputField field in loginTextFields)
        {
            field.text = "";
        }

        //addTextFields[0].text = System.DateTime.Today.ToShortDateString();

        appointment.date = "";
        appointment.firstName = "";
        appointment.lastName = "";
        appointment.startTime = "";
        appointment.endTime = "";
        appointment.email = "";
        appointment.phone = "";
        appointment.subject = "";
        appointment.notes = "";

        dateInputed = firstNameInputed = lastNameInputed = startTimeInputed = endTimeInputed = emailInputed = phoneInputed = subjectInputed = notesInputed = false;
    }

    bool CheckDate(string date)
    {
        DateTime dateValue;
        try
        {
            dateValue = System.DateTime.Parse(date);
            //Debug.Log(date + " converted to " + dateValue);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }
    bool CheckTime(string st)
    {
        int len = st.Length;
        if (len > 7 || len < 6) return false;

        if(Char.IsDigit(st[0]))
        {
            if(Char.IsDigit(st[1]))
            {
                if (st[2] == ':' && Char.IsDigit(st[3]) && Char.IsDigit(st[4]) && Char.IsLetter(st[5]) && Char.IsLetter(st[6]))
                {
                    if((st[5] == 'a' || st[5] == 'p') && st[6] == 'm') return true;
                }
            }
            else if(st[1] == ':')
            {
                if (Char.IsDigit(st[2]) && Char.IsDigit(st[3]) && Char.IsLetter(st[4]) && Char.IsLetter(st[5]))
                {
                    if ((st[4] == 'a' || st[4] == 'p') && st[5] == 'm') return true;
                }
            }
        }

        return false;
    }
    bool CheckPeriod()
    {
        string start = appointment.date + " " + appointment.startTime;
        string end = appointment.date + " " + appointment.endTime;

        DateTime dateS;
        DateTime dateE;
        try
        {
            dateS = DateTime.Parse(start);
            //Debug.Log(start + " converted to " + dateS);
            dateE = DateTime.Parse(end);
            //Debug.Log(end + " converted to " + dateE);

            TimeSpan timeSpan = dateE.Subtract(dateS);
            Debug.Log(timeSpan);
            if(timeSpan.TotalHours <= 1) return true;

        }
        catch (FormatException)
        {
            //Debug.Log("Check Period Error");
            return false;
        }

        return false;
    }
    bool CheckAvalibility()
    {
        foreach (Appointment_Set item in appointments)
        {
            if ((appointment.date == item.date) && (appointment.ID != item.ID))
            {
                string newAppt = appointment.date + " " + appointment.startTime;
                string oldAppt = item.date + " " + item.startTime;

                DateTime date1;
                DateTime date2;
                try
                {
                    date1 = DateTime.Parse(newAppt);
                    //Debug.Log(newAppt + " converted to " + date1);
                    date2 = DateTime.Parse(oldAppt);
                    //Debug.Log(oldAppt + " converted to " + date2);

                    TimeSpan timeSpan = date2.Subtract(date1);
                    //Debug.Log(timeSpan);
                    if (Mathf.Abs((float)timeSpan.TotalHours) < 1) return false;
                }
                catch (FormatException)
                {
                    //Debug.Log("Check Avalibility Error");
                    return false;
                }
            }
        }

        return true;
    }
    bool CheckPast()
    {
        DateTime date1;
        DateTime date2;
        try
        {
            date1 = DateTime.Parse(appointment.date);
            date2 = DateTime.Now;

            if (date1.CompareTo(date2) < 0) return false;
            else return true;
        }
        catch (FormatException)
        {
            FindObjectOfType<Buttons>().Error("Past Parse Error");
            return false;
        }
    }

    void ActivateAddButton()
    {
        if (dateInputed && firstNameInputed && lastNameInputed && startTimeInputed && endTimeInputed && emailInputed && phoneInputed && subjectInputed && notesInputed)
        {
            confirmAddButton.SetActive(true);
            confirmAddButtonText.SetActive(false);
        }
    }

    public void SetAppointmentDate(string st)
    {
        dateInputed = false;
        //DateTime dateValue;

        //string dateString = "2/16/2008";
        //try
        //{
        //    dateValue = DateTime.Parse(dateString);
        //    Debug.Log(dateString + " converted to " + dateValue);
        //}
        //catch (FormatException)
        //{
        //    Debug.Log("Unable to convert " + dateString);
        //}

        if (st != null && st != "")
        {
            appointment.date = st;
            dateInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentFirstName(string st)
    {
        firstNameInputed = false;

        if(st != null && st != "")
        {
            appointment.firstName = st;
            firstNameInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentLastName(string st)
    {
        lastNameInputed = false;

        if (st != null && st != "")
        {
            appointment.lastName = st;
            lastNameInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentStartTime(string st)
    {
        startTimeInputed = false;

        if (st != null && st != "")
        {
            appointment.startTime = st;
            startTimeInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentEndTime(string st)
    {
        endTimeInputed = false;

        if (st != null && st != "")
        {
            appointment.endTime = st;
            endTimeInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentEmail(string st)
    {
        emailInputed = false;

        if (st != null && st != "")
        {
            appointment.email = st;
            emailInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentPhone(string st)
    {
        phoneInputed = false;

        if (st != null && st != "")
        {
            appointment.phone = st;
            phoneInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentSubject(string st)
    {
        subjectInputed = false;

        if (st != null && st != "")
        {
            appointment.subject = st;
            subjectInputed = true;
            ActivateAddButton();
        }
    }
    public void SetAppointmentNotes(string st)
    {
        notesInputed = false;

        if (st != null && st != "")
        {
            appointment.notes = st;
            notesInputed = true;
            ActivateAddButton();
        }
    }

    public void setLoginPassword(string st)
    {
        string temp;
        // Use input string to calculate MD5 hash
        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
        {
            byte[] inputBytes = Encoding.ASCII.GetBytes(st);
            byte[] hashBytes = md5.ComputeHash(inputBytes);

            // Convert the byte array to hexadecimal string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            temp = sb.ToString().ToLower();
        }

        login.password = temp;
    }
    public void setLoginName(string st)
    {
        login.username = st;
    }

    Appointment_Set integrityAppointment = new Appointment_Set();

    public void ConfirmAppointmentButton()
    {
        // check for different conditions
        if (!CheckDate(appointment.date))
        {
            Error("Date Incorrect\nFormat as: 11/30/2020");
            return;
        }

        if (!CheckTime(appointment.startTime))
        {
            Error("Start Time Incorrect\nFormat as: 8:00pm, 12:00pm");
            return;
        }

        if (!CheckTime(appointment.endTime))
        {
            Error("End Time Incorrect\nFormat as: 8:00pm, 12:00pm");
            return;
        }

        if (!CheckPeriod())
        {
            Error("Appointments Can Be Max Of 1 Hour");
            return;
        }

        if(!CheckAvalibility())
        {
            Error("The Doctor Is Busy At That Time Please Pick Another Time");
            return;
        }

        if (!CheckPast())
        {
            Error("Please Do Not Select A past Date");
            return;
        }

        db.AddAppointment(appointment);
        
        integrityAppointment.date = appointment.date;
        integrityAppointment.firstName = appointment.firstName;
        integrityAppointment.lastName = appointment.lastName;
        integrityAppointment.startTime = appointment.startTime;
        integrityAppointment.endTime = appointment.endTime;
        integrityAppointment.email = appointment.email;
        integrityAppointment.phone = appointment.phone;
        integrityAppointment.subject = appointment.subject;
        integrityAppointment.notes = appointment.notes;

        //refresh everything
        RefreshFields();

        confirmAddButton.SetActive(false);
        confirmAddButtonText.SetActive(true);
        //FindObjectOfType<Navigation>().NavigateToPage(homePage);
    }

    public void ConfirmLogin()
    {
        db.Login(login);
    }

    public void Error(string error)
    {
        //Debug.Log("Error: " + error);
        errorDisplay.SetActive(true);
        errorText.text = "Error: " + error;
    }

    public void Confirm(string firstname, int ID)
    {
        integrityAppointment.ID = ID;
        appointments.Add(integrityAppointment);

        FindObjectOfType<Navigation>().NavigateToPage(confirmDisplay);
        confirmText.text = "Thank you for placing an appointment " + firstname + "\nYour Unique Appointment ID is: " + ID;
    }
    public void Confirm(string subject)
    {
        FindObjectOfType<Navigation>().NavigateToPage(confirmDisplay);
        confirmText.text = "You have successfully deleted your appointment for " + subject;
    }

    public void Login(int ID)
    {
        FindObjectOfType<Navigation>().NavigateToPage(appointmentPage);
        al.appointments1 = appointments;
        al.Refresh();
    }

    int ID = -1;
    string lastName;

    public void setEditID(string st)
    {
        if (!int.TryParse(st, out ID) && st != "")
        {
            Error("Invalid ID");
            ID = -1;
        }
    }
    public void setEditLastName(string st)
    {
        lastName = st;
    }

    public void Edit()
    {
        Appointment_Set search = Search(ID, lastName);
        if (search != null)
        {
            FindObjectOfType<Navigation>().NavigateToPage(editPage);

            appointment = search;

            editTextFields[0].text = appointment.date;
            editTextFields[1].text = appointment.firstName;
            editTextFields[2].text = appointment.lastName;
            editTextFields[3].text = appointment.startTime;
            editTextFields[4].text = appointment.endTime;
            editTextFields[5].text = appointment.email;
            editTextFields[6].text = appointment.phone;
            editTextFields[7].text = appointment.subject;
            editTextFields[8].text = appointment.notes;
        }
        else
        {
            Error("Appointment Not In System");
        }
        
    }
    public void confirmEditButton()
    {
        // check for different conditions
        if (!CheckDate(appointment.date))
        {
            Error("Date Incorrect\nFormat as: 11/30/2020");
            return;
        }

        if (!CheckTime(appointment.startTime))
        {
            Error("Start Time Incorrect\nFormat as: 8:00pm, 12:00pm");
            return;
        }

        if (!CheckTime(appointment.endTime))
        {
            Error("End Time Incorrect\nFormat as: 8:00pm, 12:00pm");
            return;
        }

        if(!CheckPeriod())
        {
            Error("Appointments Can Be Max Of 1 Hour");
            return;
        }

        if (!CheckAvalibility())
        {
            Error("The Doctor Is Busy At That Time Please Pick Another Time");
            return;
        }

        if (!CheckPast())
        {
            Error("Please Do Not Select A past Date");
            return;
        }

        db.EditAppointment(appointment);

        //refresh everything
        RefreshFields();

        FindObjectOfType<Navigation>().NavigateToPage(homePage);
    }


    Appointment_Set Search(int ID, string lastname)
    {
        foreach (Appointment_Set item in appointments)
        {

            if(item.lastName == lastname && item.ID == ID)
            {
                return item;
            }
        }

        return null;
    }

    public void Delete(int ID)
    {
        foreach (Appointment_Set item in appointments)
        {
            if (item.ID == ID)
            {
                appointments.Remove(item);
                Delete_Set set = new Delete_Set();
                set.ID = ID;
                db.Delete(set);
            }
        }
    }
    public void UserDelete()
    {
        string sub;

        foreach (Appointment_Set item in appointments) // mark for deletion do not imediatly trash
        {
            if (item.ID == ID)
            {
                string start = item.date + " " + item.startTime;

                DateTime date1 = DateTime.Now;
                DateTime date2;
                try
                {
                    date2 = DateTime.Parse(start);
                    TimeSpan timeSpan = date2.Subtract(date1);
                    //Debug.Log(timeSpan);

                    if (timeSpan.TotalHours <= 48)
                    {
                        Error("Can only delete an appointment up to 48 hours before the appointment date.");
                    }
                    else
                    {
                        sub = item.subject;
                        appointments.Remove(item);
                        Delete_Set set = new Delete_Set();
                        set.ID = ID;
                        db.Delete(set);
                        RefreshFields();
                        Confirm(sub);
                    }
                }
                catch (FormatException)
                {
                    Error("48 Hour Delete Error");
                }
            }
        }
    }

    List<Appointment_Set> appointments = new List<Appointment_Set>();

    public void SetActiveLoad(Load_Get get)
    {
        foreach (string appoint in get.results)
        {
            int i = 0;
            string tempS = "";

            int id = 0;
            string d = "";
            string fn = "";
            string ln = "";
            string st = "";
            string et = "";
            string p = "";
            string e = "";
            string s = "";
            string n = "";

            while (appoint[i] != '|') // ID
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            id = int.Parse(tempS);
            tempS = "";
            i++;

            while (appoint[i] != '|') // Date
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            d = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // First Name
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            fn = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // Last Name
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            ln = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // Start
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            st = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // End
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            et = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // Phone
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            p = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // Email
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            e = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // Subject
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            s = tempS;
            tempS = "";
            i++;

            while (appoint[i] != '|') // notes
            {
                tempS += appoint[i++];
            }

            //Debug.Log(tempS);
            n = tempS;
            tempS = "";
            i++;

            Appointment_Set tempAppointment = new Appointment_Set
            {
                ID = id,

                date = d,
                firstName = fn,
                lastName = ln,
                startTime = st,
                endTime = et,
                email = e,
                phone = p,
                subject = s,
                notes = n,
            };

            appointments.Add(tempAppointment);
        }
    }
}
