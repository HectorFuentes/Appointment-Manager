<?php

	$inData = getRequestInfo();

	$conn = new mysqli("localhost", "hector", "p2lqO6]dJX2:7B", "hector_db");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{
		// added two new columns
        $sql = "UPDATE Apointments set date ='" . $inData["date"] . "',  startTime ='" . $inData["startTime"] . "', email ='" . $inData["email"] . "', endTime ='" . $inData["endTime"] . "', firstName ='" . $inData["firstName"] . "', lastName ='" . $inData["lastName"] . "', phone ='" . $inData["phone"] . "', subject ='" . $inData["subject"] . "', notes ='" . $inData["notes"] ."' WHERE ID = '" . $inData["ID"] . "'";
		$conn->query($sql);
		$conn->close();
	}

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"results":["what the heck"],"error":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}
?>
