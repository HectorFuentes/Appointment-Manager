<?php

	$inData = getRequestInfo();

	$conn = new mysqli("localhost", "hector", "p2lqO6]dJX2:7B", "hector_db");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{
		$sql = "DELETE from Apointments where ID = '" . $inData["ID"] . "'";
		$conn->query($sql);
		$conn->close();
	}

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function returnWithError( $err )
	{
		$retValue = '{"id":0,"firstName":"","lastName":"","error":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}
?>
