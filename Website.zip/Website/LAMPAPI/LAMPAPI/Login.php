<?php
	$inData = getRequestInfo();

	$id = 0;
	
	$conn = new mysqli("localhost", "hector", "p2lqO6]dJX2:7B", "hector_db");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{
		$sql = "SELECT * FROM Admin where username='" . $inData["username"] . "' and Password='" . $inData["password"] . "'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0)
		{
			$row = $result->fetch_assoc();
			$id = $row["ID"];

			returnWithInfo($id);
		}
		else
		{
			returnWithError( "Incorrect Login" );
		}
		$conn->close();
	}

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"error":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}

	function returnWithInfo($id)
	{
		$retValue = '{"ID":' . $id . ',"error":""}';
		sendResultInfoAsJson( $retValue );
	}

?>
