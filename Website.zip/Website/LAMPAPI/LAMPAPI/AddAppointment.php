<?php
	$inData = getRequestInfo();

	$date = $inData["date"];
	$startTime = $inData["startTime"];
	$endTime = $inData["endTime"];
	$firstName = $inData["firstName"];
	$lastName = $inData["lastName"];
	$phone = $inData["phone"];
	$email = $inData["email"];
	$subject = $inData["subject"];
	$notes = $inData["notes"];

	$conn = new mysqli("localhost", "hector", "p2lqO6]dJX2:7B", "hector_db");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{
		$sql = "INSERT into Apointments (date, startTime, endTime, firstName, lastName, phone, email, subject, notes) VALUES ('" . $date . "','" . $startTime . "','" . $endTime . "','" . $firstName . "','" . $lastName . "','" . $phone . "','" . $email . "','" . $subject . "','" . $notes . "')";
		if( $result = $conn->query($sql) != TRUE )
		{
			returnWithError( $conn->error );
		}
		else
		{
			$sql = "SELECT * FROM Apointments where date = '" . $date . "' and startTime = '" . $startTime . "' and endTime = '" . $endTime . "'";
			$result = $conn->query($sql);
			if ($result->num_rows > 0)
			{
				$row = $result->fetch_assoc();
				$firstName = $row["firstName"];
				$id = $row["ID"];

				returnWithInfo($firstName, $id);
			}
			else
			{
				returnWithError( "No Records Found" );
			}
		}
		$conn->close();
	}

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"error":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}
	
	function returnWithInfo( $firstName, $ID)
	{
		$retValue = '{"message":"Successful login.","ID":' . $ID . ',"firstName":"' . $firstName . '","error":""}';
		sendResultInfoAsJson( $retValue );
	}

?>
 